from aisprayer.main import run

run()

# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['aisprayer']

package_data = \
{'': ['*'], 'aisprayer': ['static/*', 'templates/*']}

install_requires = \
['RPi.GPIO>=0.7.1,<0.8.0',
 'gpiozero>=1.5,<1.6',
 'picamera>=1.13,<1.14',
 'pillow>=7.2,<7.3',
 'pyyaml>=5.3.1,<5.4.0',
 'requests>=2.24,<2.25']

setup_kwargs = {
    'name': 'aisprayer',
    'version': '0.5.0',
    'description': 'Detect unwanted animals in front of camera and sprays water on them',
    'long_description': None,
    'author': 'Christoffer Kongstad',
    'author_email': 'christoffersk@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)

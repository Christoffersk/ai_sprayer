import requests
import logging
from PIL import ImageDraw, Image, ImageChops
import os
import numpy as np

from .config_handler import ConfigHandler
from .interface_helper import Interface


class Detector:
    def __init__(self):
        self.c = ConfigHandler()
        self.api_endpoint = self.c.get("API_ENDPOINT")
        self.last_image = None
        self.interface = Interface()

    def detect(self, image, image_stream):
        alarm = False

        motion = self._detect_motion(image)

        if motion:
            detections = self._detect_object(image, image_stream)

            if detections:
                alarm = True

        return alarm

    def _calculate_position(self, detections, image):

        positions = []
        for detection in detections:
            x = detection["x_min"] + ((detection["x_max"] - detection["x_min"]) / 2)
            y = detection["y_min"] + ((detection["y_max"] - detection["y_min"]) / 3 * 2)

            positions.extend([{"x": x, "y": y}])

        logging.debug(positions)
        return positions

    def _calculate_image_entropy(self, image):
        w, h = image.size
        a = np.array(image.convert("RGB")).reshape((w * h, 3))
        h, _ = np.histogramdd(a, bins=(16,) * 3, range=((0, 256),) * 3)
        prob = h / np.sum(h)
        prob = prob[prob > 0]
        entropy = -np.sum(prob * np.log2(prob))
        return entropy

    def _detect_motion(self, image):
        resize_size = (128, 96)
        small_image = image.resize(resize_size, Image.ANTIALIAS)

        threshold = self.c.get("MOTION_THRES")

        if self.last_image is None:
            self.last_image = small_image

        difference = ImageChops.difference(small_image, self.last_image)
        entropy = self._calculate_image_entropy(difference)

        self.last_image = small_image
        logging.debug(entropy)

        if entropy > threshold:
            return True

        return False

    def _detect_object(self, image, image_stream):
        response = self._post_image(image_stream)
        valid_detections = []

        try:
            detections = [
                prediction
                for prediction in response["predictions"]
                if (
                    prediction["label"] in self.c.get("TARGETS")
                    and prediction["confidence"] > self.c.get("CONFIDENCE_THRES")
                )
            ]
            logging.debug(detections)

        except Exception:
            detections = []

        if detections:
            positions = self._calculate_position(detections, image)

            valid_detections = [
                detection
                for detection, position in zip(detections, positions)
                if (position["y"] > self.c.get("SPRAY_POSITION_LIMIT_TOP"))
            ]
            logging.debug(valid_detections)

            detect_image = self._draw_detections(image, detections, positions)
            self.interface.send_image(detect_image, "detect_image")

        return valid_detections

    def _draw_detections(self, image, detections, positions):

        for prediction, position in zip(detections, positions):
            shape = [
                (prediction["x_min"], prediction["y_min"]),
                (prediction["x_max"], prediction["y_max"]),
            ]

            # create rectangle image
            img_drawer = ImageDraw.Draw(image)
            img_drawer.rectangle(shape, outline="red", width=3)
            img_drawer.text(
                (prediction["x_min"], prediction["y_min"]),
                str(prediction["confidence"]),
            )
            img_drawer.text(
                (prediction["x_min"], prediction["y_min"] + 30),
                str(prediction["label"]),
            )
            ell_size = 5
            img_drawer.ellipse(
                [
                    (position["x"] - ell_size, position["y"] - ell_size),
                    (position["x"] + ell_size, position["y"] + ell_size),
                ],
                fill=(255, 0, 0, 255),
            )

        return image

    def _post_image(self, image_stream):
        response = requests.post(
            self.api_endpoint, files={"image": image_stream}
        ).json()
        logging.debug(response)
        return response

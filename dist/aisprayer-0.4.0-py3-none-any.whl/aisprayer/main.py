from .runner import Runner

from .frontend import run_frontend
import threading
import queue


def run():
    q = queue.Queue()

    # Backend
    runner = Runner()
    threading.Thread(target=runner.run, args=(q,)).start()

    # Frontend
    threading.Thread(target=run_frontend, args=(q,)).start()


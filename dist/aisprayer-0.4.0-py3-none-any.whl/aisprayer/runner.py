from time import sleep
import time
import requests
import logging
from PIL import ImageDraw
import queue

# from .sprayer import Sprayer
from .camera import Camera
from .detection import Detector
from .sprayer import Sprayer
from .config_handler import ConfigHandler
from .interface_helper import Interface


class Runner:
    def __init__(self):
        logging.basicConfig(
            filename="/home/pi/logs/aisprayer.log",
            level=logging.INFO,
            format="%(asctime)s %(levelname)-8s %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )
        logging.info("Started")
        self.c = ConfigHandler()
        self.sprayer = Sprayer()
        self.camera = Camera()
        self.detector = Detector()
        self.interface = Interface()
        self.last_image_time = 0

    def _interval_keeper(self, run_time):
        logging.debug(f"The code runs in {run_time}s")
        if run_time > self.c.get("PROGRAM_INTERVAL"):
            logging.warning(f"Code runs to slowly {run_time}s")
        else:
            sleep(self.c.get("PROGRAM_INTERVAL") - run_time)

    def _send_image(self, image):
        self.last_image_time = time.time()
        top_limit = self.c.get("SPRAY_POSITION_LIMIT_TOP")
        width, _ = image.size
        img_drawer = ImageDraw.Draw(image)
        img_drawer.line(
            xy=[(0, top_limit), (width, top_limit)], fill=(255, 255, 255, 100), width=1,
        )
        self.interface.send_image(image, "image")

    def run(self, q_in):
        q = q_in

        # Program loop
        while True:
            start_time = time.time()
            self.camera.capture()
            image = self.camera.get_image()
            image_stream = self.camera.get_stream()
            alarm = self.detector.detect(image, image_stream)

            if time.time() - self.last_image_time > self.c.get(
                "CAMERA_UPDATE_INTERVAL"
            ):
                self._send_image(image)

            try:
                manual_spray = q.get(block=False)
            except queue.Empty:
                manual_spray = False

            if alarm:
                self.sprayer.spray()
                logging.info("Cat detected")
            elif manual_spray:
                manual_spray = False
                self.sprayer.spray()
                logging.info("Manual spray")

            run_time = time.time() - start_time
            self._interval_keeper(run_time)

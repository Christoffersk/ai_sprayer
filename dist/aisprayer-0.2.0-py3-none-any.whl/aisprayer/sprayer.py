class Sprayer:
    def __init__(self, pin):
        self.pin = pin

    def spray(self):
        pass
